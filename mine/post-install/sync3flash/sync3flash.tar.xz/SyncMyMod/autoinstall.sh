#!/bin/sh
#####################################################################################################################################################################
#															 IFS-REFORMAT MOD (1U5T-14G386-CB) V1.3																	#
#														 bigunclemax, Sanek2033, chautruongthinh, A-TEAM															#
#																		https://ffclub.ru																			#
#####################################################################################################################################################################

#########################################################################################################################################################
#																Check if Mods Tools are installed														.#
#########################################################################################################################################################

if [[ ! -f "/fs/rwdata/dev/utserviceutility" || ! -f "/fs/rwdata/dev/patch" || ! -f "/fs/rwdata/dev/remount_rw.sh" || ! -f "/fs/rwdata/dev/remount_ro.sh" ]]; then
	slay APP_SUM
	slay -s 9 NAV_Manager
	slay -s 9 fordhmi
	slay HMI_AL
	display_image -file=/fs/usb0/SyncMyMod/installation_aborted.png -display=2 &

	while [ -e /fs/usb0 ]; do
		sleep 1
	done

	shutdown
else
	chmod a+x /fs/rwdata/dev/*
	
	#########################################################################################################################################################
	#########################################################################################################################################################
	#########################################################################################################################################################.
	cp /fs/usb0/SyncMyMod/MLO /tmp
	cp /fs/usb0/SyncMyMod/QNX-IFS-REFORMAT /tmp
	sync
	chmod 777 /tmp/MLO
	chmod 777 /tmp/QNX-IFS-REFORMAT
	sync
	echo "" >> /tmp/popup.txt
	echo "" >> /tmp/popup.txt
	echo "Wait 2 seconds" >> /tmp/popup.txt
	echo "" >> /tmp/popup.txt
	echo "Script Started, DO NOT REMOVE THE USB!" >> /tmp/popup.txt
	echo "https://ffclub.ru" >> /tmp/popup.txt
	echo "Sanek2033, bigunclemax, chautruongthinh, A-TEAM" >> /tmp/popup.txt
	/fs/rwdata/dev/utserviceutility popup /tmp/popup.txt
	sleep 2
	rm /tmp/popup.txt

	if [ -e /tmp/QNX-IFS-REFORMAT ] && [ -e /tmp/MLO ] ; then
		# -t option flash passive bank, and switch to it on success
		update_boot -t -i /tmp/QNX-IFS-REFORMAT -m /tmp/MLO
        if [ $? -ne 0 ]; then

			echo "Flash passive bank error! Trying to flash active bank..." >> /tmp/popup.txt
			/fs/rwdata/dev/utserviceutility popup /tmp/popup.txt
        	# -r option is actually flash both banks 
			update_boot -r -i /tmp/QNX-IFS-REFORMAT -m /tmp/MLO    
            if [ $? -ne 0 ]; then
                echo "Flash active bank error! You sync is probabby already brick ;)" >> /tmp/popup.txt
				/fs/rwdata/dev/utserviceutility popup /tmp/popup.txt
            fi                  
        fi              
    else
        echo "Reformatter not installed: No MLO or No IFS" >> /tmp/popup.txt
		fs/rwdata/dev/utserviceutility popup /tmp/popup.txt
    fi
	
	sync
	sync
	#########################################################################################################################################################.
	#########################################################################################################################################################
	#########################################################################################################################################################
	sleep 1
	slay APP_SUM
	slay -s 9 NAV_Manager
	slay -s 9 fordhmi
	slay HMI_AL
	display_image -file=/fs/usb0/SyncMyMod/installation_completed.png -display=2 &
	while [ -e /fs/usb0 ]; do
		sleep 1
	done

	/fs/rwdata/dev/utserviceutility reboot
fi
